import { Component } from '@angular/core';

@Component({
  selector: 'app-withdrawmoney',
  templateUrl: './withdrawmoney.component.html',
  styleUrls: ['./withdrawmoney.component.css']
})
export class WithdrawmoneyComponent {

}
