import { Component } from '@angular/core';

@Component({
  selector: 'app-depositmoney',
  templateUrl: './depositmoney.component.html',
  styleUrls: ['./depositmoney.component.css']
})
export class DepositmoneyComponent {

}
